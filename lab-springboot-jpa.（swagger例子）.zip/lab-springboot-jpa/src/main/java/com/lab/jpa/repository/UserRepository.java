package com.lab.jpa.repository;

import com.lab.jpa.entity.User;
import org.springframework.stereotype.Repository;

import java.io.Serializable;

/**
 * Created by zhaohuan on 2017/9/17.
 */
@Repository
public interface UserRepository<T, ID extends Serializable> extends BaseRepository<User, ID> {
}
