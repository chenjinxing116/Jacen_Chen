package com.lab.jpa.controller;

import com.lab.jpa.entity.Department;
import com.lab.jpa.entity.Role;
import com.lab.jpa.entity.User;
import com.lab.jpa.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by zhaohuan on 2017/9/17.
 */
@RestController
public class UserController {
    @Autowired
    UserRepository userRepository;
    
    @ResponseBody
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public String hello() {
        return "Hello World";
    }

    @RequestMapping(value = "/save", method = RequestMethod.GET)
    public Object index(ModelMap map) {
        User user = new User("wangliu", 18);
        user.setUser_id(1L);
        Department dept = new Department();
        dept.setName("org1");

        user.setDept(dept);
        Set set = new HashSet<>();
        Role role1 = new Role();
        //role1.setRole_id(1L);
        role1.setName("role1");
        Role role2 = new Role();
        //role1.setRole_id(2L);
        role2.setName("role2");
        set.add(role1);
        set.add(role2);
        user.setRoles(set);
        return userRepository.save(user);
    }

}