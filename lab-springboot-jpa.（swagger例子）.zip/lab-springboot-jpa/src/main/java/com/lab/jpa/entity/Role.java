package com.lab.jpa.entity;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by zhaohuan on 2017/9/17.
 */
@Entity
@Table(name = "t_role")
public class Role {

    @Id
    @GeneratedValue
    private Long role_id;

    @Column
    private String name;

    @ManyToMany(mappedBy = "roles")
    private Set<User> users;

    public Long getRole_id() {
        return role_id;
    }

    public void setRole_id(Long role_id) {
        this.role_id = role_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }
}
