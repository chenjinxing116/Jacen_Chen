package com.lab.jpa.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * Created by zhaohuan on 2017/9/17.
 */
@Entity
@Table(name = "t_department")
public class Department implements Serializable {

    @Id
    @GeneratedValue
    private int org_id;

    @Column
    private String name;

    public Department() {}

    public Department(String name) {
        this.name = name;
    }

    @OneToMany(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY, mappedBy = "dept")
    private Set<User> users;

    public int getOrg_id() {
        return org_id;
    }

    public void setOrg_id(int org_id) {
        this.org_id = org_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
