package com.lab.jpa.repository;


import com.lab.jpa.entity.Department;
import java.io.Serializable;

/**
 * Created by zhaohuan on 2017/9/24.
 */
public interface DeptRepository<T, ID extends Serializable> extends BaseRepository<Department, ID> {
}
