package com.lab.jpa;

import com.Application;
import com.lab.jpa.entity.Department;
import com.lab.jpa.entity.User;
import com.lab.jpa.repository.UserRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by zhaohuan on 2017/9/24.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(Application.class)
public class ApplicationTest {

    @Autowired
    UserRepository userRepository;

    @Test
    public void saveUser() {

        /**
         * 单独保存
         *      @Id 注解会自动生成id
         */
        User user = new User("张三", 20);
        userRepository.save(user);
    }

    @Test
    public void saveUserNotPersisentDepartment() {

        /**
         * 配置项：
         *      @ManyToOne(cascade = {CascadeType.REFRESH}, fetch = FetchType.EAGER)
         *      @JoinColumn(name = "org_id")
         *      private Department dept;
         *
         * 运行结果：
         *       报错：TransientPropertyValueException: object references an unsaved transient instance -
         *       save the transient instance before flushing : com.lab.entity.User.dept -> com.lab.entity.Department
         *
         * 原因分析：用户对部门是@ManyToOne的关系
         *      1，用户inverse为false，用户会维护双方关系。所以用户在update保存关系的时候找不到一个持久化的部门对象。
         *      部门在这个场景中的状态是an unsaved transient instance
         *
         * 解决保存的方式：
         *      1，设置cascade = {CascadeType.PERSIST}，在保存用户的时候会级联保存部门。当更新用户部门关系的时候，部门被持久化了，就不会报错。
         *          结果：用户和部门都会insert到数据库。
         *          Hibernate: insert into t_department (name) values (?)
         *          Hibernate: insert into t_user (age, org_id, name) values (?, ?, ?)
         *
         * 延伸：
         *      optional选项 => 是否关联,如果设置为optional = false，一个non-null的关联关系将存在。
         *
         *      含义：
         *      1，optional 属性是定义该关联类对是否必须存在，值为false时，关联类双方都必须存在，如果关系被维护端不存在，查询的结果为null。
         *      2，值为true 时, 关系被维护端可以不存在，查询的结果仍然会返回关系维护端，在关系维护端中指向关系被维护端的属性为null。
         *      3，optional 属性的默认值是true。举个例：某项订单(Order)中没有订单项(OrderItem)，如果optional 属性设置为false，
         *      获取该项订单（Order）时，得到的结果为null，如果optional 属性设置为true，仍然可以获取该项订单，但订单中指向订单项的属性为null。
         *
         *      实际上在解释Order 与OrderItem的关系成SQL时，optional 属性指定了他们的联接关系
         *          optional=false联接关系为inner join,
         *          optional=true联接关系为left join。
         *
         *
         */
        User user = new User("张三", 20);
        Department dept = new Department("部门一");
        user.setDept(dept);

        userRepository.save(user);

    }

    @Test
    public void saveUserNotPersisentAndUseMergeDepartment() {

        /**
         * 配置项：
         *       @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.EAGER)
         *       @JoinColumn(name = "org_id")
         *       private Department dept;
         *
         * 运行结果：失败。
         *      异常信息：TransientPropertyValueException: object references an unsaved transient instance - save the
         *      transient instance before flushing : com.lab.entity.User.dept -> com.lab.entity.Department;
         *      nested exception is java.lang.IllegalStateException: org.hibernate.TransientPropertyValueException:
         *      object references an unsaved transient instance - save the transient instance before flushing :
         *      com.lab.entity.User.dept -> com.lab.entity.Department
         *
         * 原因分析：
         *      merge是级联修改的意思，就是说当update了一个用户，并且这个用户的部门信息也更改了。会级联update部门的信息。
         *
         *      merge使用场景可以是电商项目中，订单和商品的场景。
         *      当订单的收获地址变更了，而且商品颜色也变更了，就可以使用merge。
         */

        User user = new User("张三", 20);
        Department dept = new Department("部门一");
        user.setDept(dept);

        userRepository.save(user);
    }




}
